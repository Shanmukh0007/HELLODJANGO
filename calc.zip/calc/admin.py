from django.contrib import admin

# Register your models hereimpor
from .models import *

admin.site.register(Customer)
admin.site.register(Products)
admin.site.register(Tag)
admin.site.register(Order)